# Backport of OpenJFX Dialogs to JDK7

Dialogs were released in JavaFX 8u40. This library allows you to use them in JDK7.

Available on [jCenter](https://bintray.com/bintray/jcenter?filterByPkgName=openjfx-dialogs-jdk7):
```xml
    <dependency>
        <groupId>it.bertel.openjfx-dialogs-jdk7</groupId>
        <artifactId>openjfx-dialogs-jdk7</artifactId>
        <version>1.0.0</version>
    </dependency>
```

## Is the API _really_ the same?

**No**, that wasn't possible. In fact, the `Dialog#showAndWait()` method return a [Java8 Optional](https://docs.oracle.com/javase/8/docs/api/java/util/Optional.html).
This library will return a *nullable reference* instead.

That's the only (known) difference, but there are workarounds to maintain forward compatibility.

### Option 1: do not use the return value of #showAndWait()

```java
    Alert a1 = new Alert(Alert.AlertType.INFORMATION);
    a1.setContentText("Does it work with both JDK7 and JDK8?");
    a1.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);
    a1.showAndWait();
    if (a1.getResult() != null && a1.getResult() == ButtonType.YES) {
    	System.out.println("I think so!");
    }
```

### Option 2: wrap the return value of #shopwAndWait()

You can, for example, wrap the return value by using [Optionalizer](https://github.com/BertelSpA/optionalizer),
which can convert the nullable reference (JDK7) or the Java8 Optional (JDK8) to a Guava Optional.

```java
    Alert a2 = new Alert(Alert.AlertType.INFORMATION);
    a2.setContentText("Does it work with both JDK7 and JDK8?");
    a2.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);
    Optional<ButtonType> result = Optionalizer.toGuavaOptional(a2.showAndWait());
    if (result.isPresent() && result.get() == ButtonType.YES) {
    	System.out.println("I think so!");
    }
```

Dependencies in JDK7:
```
    compile "it.bertel.openjfx-dialogs-jdk7:openjfx-dialogs-jdk7:1.0.0"
    compile "it.bertel.optionalizer:optionalizer-jdk7:1.0.0"
```

Dependencies in JDK8:
```
    compile "it.bertel.optionalizer:optionalizer-jdk8:1.0.0"
```

